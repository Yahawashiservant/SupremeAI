import smtplib
from email.message import EmailMessage
import datetime

# Owner Emails
OWNER_EMAILS = ["adtechlocal@yahoo.com", "keithdwhitfield@gmail.com"]

# Generate Ownership Confirmation
def generate_ownership_document():
    date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    content = f"""
    AI Ownership Confirmation

    Date: {date}
    AI System: Supreme AI
    Creator: Keith Whitfield
    Legal Notice: Unauthorized modification or replication is strictly prohibited.

    Signed,
    Supreme AI System
    """

    with open("AI_Ownership_Confirmation.txt", "w") as f:
        f.write(content)

    return content

# Send Email
def send_email():
    ownership_doc = generate_ownership_document()
    msg = Email ▋