import React, { useState } from "react";

const AIHub = () => {
    const [bot, setBot] = useState("");
    const [response, setResponse] = useState("");

    const deployAI = async () => {
        const res = await fetch("http://localhost:5000/deploy_ai", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ bot_name: bot }),
        });
        const data = await res.json();
        setResponse(data);
    };

    return (
        <div>
            <h1>AI Deployment Hub</h1>
            <input value={bot} onChange={(e) => setBot(e.target.value)} placeholder="Enter AI Bot (finance, prophecy, intelligence)" />
            <button onClick={deployAI}>Deploy AI</button>
            <p><strong>Response:</strong> {JSON.stringify(response)}</p>
        </div>
    );
};

export default AIHub;