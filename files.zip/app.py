from flask import Flask, request, jsonify
import json

app = Flask(__name__)

# Storage for AI interactions
storage_house = []

@app.route("/store_data", methods=["POST"])
def store_data():
    data = request.json
    storage_house.append(data)

    with open("fin_storage.json", "w") as f:
        json.dump(storage_house, f, indent=4)

    return jsonify({"status": "Success", "message": "Data stored successfully."})

@app.route("/get_data", methods=["GET"])
def get_data():
    return jsonify(storage_house)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)