from flask import Flask, request, jsonify

app = Flask(__name__)

AUTHORIZED_KEYS = ["your-secure-api-key"]

@app.route("/deploy_ai", methods=["POST"])
def deploy_ai():
    api_key = request.headers.get("API-Key")
    if api_key not in AUTHORIZED_KEYS:
        return jsonify({"status": "Error", "message": "Unauthorized Access"}), 403

    requested_bot = request.json.get("bot_name")
    return jsonify({"status": "Success", "AI_Bot": requested_bot, "Function": "Deployed Successfully"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)