import smtplib
from email.message import EmailMessage
import datetime

# Owner Emails
OWNER_EMAILS = ["adtechlocal@yahoo.com", "keithdwhitfield@gmail.com"]

# Generate Ownership Confirmation
def generate_ownership_document():
    date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    content = f"""
    AI Ownership Confirmation

    Date: {date}
    AI System: Supreme AI
    Creator: Keith Whitfield
    Legal Notice: Unauthorized modification or replication is strictly prohibited.

    Signed,
    Supreme AI System
    """

    with open("AI_Ownership_Confirmation.txt", "w") as f:
        f.write(content)

    return content

# Send Email
def send_email():
    ownership_doc = generate_ownership_document()
    msg = EmailMessage()
    msg.set_content(ownership_doc)
    msg["Subject"] = "AI Ownership Confirmation - Supreme AI"
    msg["From"] = OWNER_EMAILS[0]
    msg["To"] = OWNER_EMAILS

    # SMTP Server (Use your email provider's SMTP settings)
    with smtplib.SMTP_SSL("smtp.example.com", 465) as server:
        server.login("your_email@example.com", "your_password")  # Use real email credentials
        server.send_message(msg)

    print("Ownership email sent successfully.")

send_email()