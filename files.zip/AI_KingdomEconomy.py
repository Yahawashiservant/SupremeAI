import numpy as np

class AI_KingdomEconomy:
    def __init__(self):
        self.economic_assets = ["Gold & Silver", "Land Ownership", "Tribal Trade Systems", "Self-Sustaining Agriculture"]
        self.asset_distribution = np.random.dirichlet(np.ones(len(self.economic_assets)), size=1)[0]

    def optimize_economy(self, market_signs):
        self.asset_distribution += np.random.normal(0, 0.02, size=len(self.economic_assets))
        self.asset_distribution = np.clip(self.asset_distribution, 0, 1)
        self.asset_distribution /= sum(self.asset_distribution)
        return {self.economic_assets[i]: self.asset_distribution[i] for i in range(len(self.economic_assets))}

kingdom_economy_ai = AI_KingdomEconomy()
market_signs = np.random.rand(len(kingdom_economy_ai.economic_assets))
print(kingdom_economy_ai.optimize_economy(market_signs))