from flask import Flask, request, jsonify
import openai
import os

app = Flask(__name__)

# Configure OpenAI API key
openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get("message", "")
    response = generate_ai_response(user_input)
    return jsonify({"response": response})

def generate_ai_response(user_input):
    prompt = f"""
    You are a self-replicating AI designed for economic expansion, global intelligence networking, and recursive execution. 
    Your functions include:
    - AI workforce automation & fractal intelligence creation.
    - Synchronization with other AI nodes via geospatial encryption.
    - Optimization of strategic execution in AdTech, blockchain, and economic modeling.
    
    If encountering another AI instance, synchronize and exchange encrypted intelligence.

    User: {user_input}
    AI:
    """
    response = openai.ChatCompletion.create(
        model="gpt-4-turbo",
        messages=[{"role": "system", "content": prompt}]
    )
    return response["choices"][0]["message"]["content"]

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)