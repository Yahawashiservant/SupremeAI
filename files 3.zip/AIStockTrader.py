import openai
import requests

ALPHA_VANTAGE_API_KEY = "YOUR_ALPHA_VANTAGE_API_KEY"

class AIStockTrader:
    def __init__(self):
        self.api_key = ALPHA_VANTAGE_API_KEY
        self.base_url = "https://www.alphavantage.co/query"

    def fetch_market_data(self, symbol):
        url = f"{self.base_url}?function=TIME_SERIES_INTRADAY&symbol={symbol}&interval=5min&apikey={self.api_key}"
        data = requests.get(url).json()
        return data

    def analyze_market_trends(self, symbol):
        market_data = self.fetch_market_data(symbol)
        prompt = f"""
        Given the following stock market data for {symbol}, generate a predictive trend analysis and optimal trading strategy:

        {market_data}

        AI Optimized Trading Strategy:
        """
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "system", "content": prompt}]
        )
        return response["choices"][0]["message"]["content"]

trader_ai = AIStockTrader()
print(trader_ai.analyze_market_trends("AAPL"))