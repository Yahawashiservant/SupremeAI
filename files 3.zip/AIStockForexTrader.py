import openai
import requests

ALPHA_VANTAGE_API_KEY = "YOUR_ALPHA_VANTAGE_API_KEY"

class AIStockForexTrader:
    def __init__(self):
        self.api_key = ALPHA_VANTAGE_API_KEY
        self.base_url = "https://www.alphavantage.co/query"

    def fetch_market_data(self, symbol, market_type="stock"):
        function = "TIME_SERIES_INTRADAY" if market_type == "stock" else "FX_INTRADAY"
        url = f"{self.base_url}?function={function}&symbol={symbol}&interval=5min&apikey={self.api_key}"
        data = requests.get(url).json()
        return data

    def generate_trade_signal(self, symbol, market_type="stock"):
        market_data = self.fetch_market_data(symbol, market_type)
        prompt = f"""
        Given the following {market_type} market data for {symbol}, generate a predictive trend analysis and the optimal trading strategy:

        {market_data}

        AI Optimized Trading Strategy:
        """
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "system", "content": prompt}]
        )
        return response["choices"][0]["message"]["content"]

trader_ai = AIStockForexTrader()
print(trader_ai.generate_trade_signal("AAPL", "stock"))
print(trader_ai.generate_trade_signal("EUR/USD", "forex"))