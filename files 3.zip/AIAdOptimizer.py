import requests

class AIAdOptimizer:
    def __init__(self):
        self.geo_api = "https://maps.googleapis.com/maps/api/geocode/json?key=YOUR_API_KEY"
    
    def find_best_market(self, product_category):
        geo_data = requests.get(self.geo_api + "&address=global").json()
        return f"Optimal market for {product_category}: {geo_data['results'][0]['formatted_address']}"

ad_ai = AIAdOptimizer()
print(ad_ai.find_best_market("Luxury Goods"))