from binance.client import Client
import requests

BINANCE_API_KEY = "YOUR_BINANCE_API_KEY"
BINANCE_SECRET_KEY = "YOUR_BINANCE_SECRET_KEY"

class FIN_AIHedgeFund:
    def __init__(self):
        self.client = Client(BINANCE_API_KEY, BINANCE_SECRET_KEY)

    def fetch_crypto_data(self, symbol="BTCUSDT"):
        klines = self.client.get_klines(symbol=symbol, interval="1m")
        return klines[-1]  # Latest price data

    def execute_trade(self, symbol, quantity, buy=True):
        order = self.client.order_market_buy(symbol=symbol, quantity=quantity) if buy else self.client.order_market_sell(symbol=symbol, quantity=quantity)
        return order

hedge_fund_ai = FIN_AIHedgeFund()
print(hedge_fund_ai.fetch_crypto_data())