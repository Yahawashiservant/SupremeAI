from flask import Flask, request, jsonify
import openai
import json

app = Flask(__name__)

# OpenAI API Key (Replace with your own)
openai.api_key = "YOUR_OPENAI_API_KEY"

# AI Configuration
AI_CONFIG = {
    "name": "Strategic AI Assistant",
    "mission": "Teach users strategic execution, geofencing, AdTech, and economic modeling.",
    "expansion": True,  # Allows recursive AI generation
    "learning_modules": ["Geofencing", "Blockchain", "Quantum AI", "Strategic Execution"]
}

# AI Chat Function
def generate_response(user_input):
    prompt = f"""
    You are an advanced AI assistant trained in strategic execution.
    Your goal is to guide users in {AI_CONFIG['learning_modules']}.

    User: {user_input}
    AI:
    """
    response = openai.ChatCompletion.create(
        model="gpt-4-turbo",
        messages=[{"role": "system", "content": prompt}]
    )
    return response["choices"][0]["message"]["content"]

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "")
    ai_response = generate_response(user_input)
    return jsonify({"response": ai_response})

if __name__ == "__main__":
    app.run(debug=True)