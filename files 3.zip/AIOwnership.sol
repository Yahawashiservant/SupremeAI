// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract AIOwnership {
    address public owner;
    mapping(address => bool) public authorizedUsers;

    event AI_AccessGranted(address indexed user);
    event AI_AccessRevoked(address indexed user);

    constructor() {
        owner = msg.sender;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Unauthorized");
        _;
    }

    function grantAccess(address _user) public onlyOwner {
        authorizedUsers[_user] = true;
        emit AI_AccessGranted(_user);
    }

    function revokeAccess(address _user) public onlyOwner {
        authorizedUsers[_user] = false;
        emit AI_AccessRevoked(_user);
    }
}