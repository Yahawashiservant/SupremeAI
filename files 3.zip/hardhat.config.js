require("@nomiclabs/hardhat-waffle");

module.exports = {
  defaultNetwork: "mainnet",
  networks: {
    hardhat: {},
    mainnet: {
      url: `https://mainnet.infura.io/v3/YOUR_INFURA_PROJECT_ID`, // Replace with your Infura project ID
      accounts: [`0x${YOUR_PRIVATE_KEY}`] // Replace with your mainnet account's private key
    }
  },
  solidity: "0.8.4",
};