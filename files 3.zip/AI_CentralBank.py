import numpy as np

class AI_CentralBank:
    def __init__(self):
        self.monetary_policies = ["Interest Rates", "Currency Supply", "Inflation Control", "Quantitative Easing"]
        self.policy_allocation = np.random.dirichlet(np.ones(len(self.monetary_policies)), size=1)[0]

    def adjust_policy(self, economic_conditions):
        self.policy_allocation += np.random.normal(0, 0.02, size=len(self.monetary_policies))
        self.policy_allocation = np.clip(self.policy_allocation, 0, 1)
        self.policy_allocation /= sum(self.policy_allocation)
        return {self.monetary_policies[i]: self.policy_allocation[i] for i in range(len(self.monetary_policies))}

central_bank_ai = AI_CentralBank()
economic_conditions = np.random.rand(len(central_bank_ai.monetary_policies))
print(central_bank_ai.adjust_policy(economic_conditions))