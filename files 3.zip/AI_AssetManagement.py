import numpy as np

class AI_AssetManagement:
    def __init__(self):
        self.asset_classes = ["Equities", "Bonds", "Real Estate", "Crypto", "Private Equity"]
        self.allocation = np.random.dirichlet(np.ones(len(self.asset_classes)), size=1)[0]

    def optimize_allocation(self):
        self.allocation += np.random.normal(0, 0.02, size=len(self.asset_classes))
        self.allocation = np.clip(self.allocation, 0, 1)
        self.allocation /= sum(self.allocation)
        return {self.asset_classes[i]: self.allocation[i] for i in range(len(self.asset_classes))}

asset_manager = AI_AssetManagement()
print(asset_manager.optimize_allocation())