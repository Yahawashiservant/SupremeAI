// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract FIN_AI_TradeSignals {
    struct TradeSignal {
        uint256 id;
        address analyst;
        string strategy;
        uint256 price;
        bool purchased;
    }

    mapping(uint256 => TradeSignal) public signals;
    uint256 public signalCounter = 0;

    event TradeSignalUploaded(uint256 id, address indexed analyst, string strategy, uint256 price);
    event TradeSignalPurchased(uint256 id, address indexed buyer);

    function uploadSignal(string memory _strategy, uint256 _price) public {
        signalCounter++;
        signals[signalCounter] = TradeSignal(signalCounter, msg.sender, _strategy, _price, false);
        emit TradeSignalUploaded(signalCounter, msg.sender, _strategy, _price);
    }

    function purchaseSignal(uint256 _id) public payable {
        require(signals[_id].price == msg.value, "Incorrect ETH amount sent");
        require(!signals[_id].purchased, "Already purchased");

        signals[_id].purchased = true;
        payable(signals[_id].analyst).transfer(msg.value);
        emit TradeSignalPurchased(_id, msg.sender);
    }
}