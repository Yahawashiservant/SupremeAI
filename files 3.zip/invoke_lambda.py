import boto3

# Initialize the Boto3 client for AWS Lambda
lambda_client = boto3.client("lambda")

# Invoke the AWS Lambda function
response = lambda_client.invoke(
    FunctionName="FIN_AI_TradeExecution",
    InvocationType="Event"
)

print("AWS Lambda Function Invoked: Trade Execution Live")