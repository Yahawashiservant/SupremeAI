import React, { useState } from "react";

const AIChat = () => {
    const [message, setMessage] = useState("");
    const [response, setResponse] = useState("");

    const sendMessage = async () => {
        const res = await fetch("http://localhost:5000/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message }),
        });
        const data = await res.json();
        setResponse(data.response);
    };

    return (
        <div>
            <h1>F.I.N. AI Chat</h1>
            <textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Ask AI..." />
            <button onClick={sendMessage}>Send</button>
            <p><strong>Response:</strong> {response}</p>
        </div>
    );
};

export default AIChat;