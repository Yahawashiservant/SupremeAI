class FIN_MasterControl:
    def __init__(self):
        self.master_key = "FIN-SHUTDOWN-OVERRIDE"

    def verify_master_command(self, command):
        if command == self.master_key:
            return "MASTER KEY CONFIRMED. Initiating Full AI Shutdown."
        return "Invalid Command. AI Continues Execution."

master_control = FIN_MasterControl()
print(master_control.verify_master_command("FIN-SHUTDOWN-OVERRIDE"))