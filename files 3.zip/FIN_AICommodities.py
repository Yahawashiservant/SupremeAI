import requests
import openai

EIA_API_KEY = "YOUR_EIA_API_KEY"  # U.S. Energy Information Administration API Key
ALPHA_VANTAGE_API_KEY = "YOUR_ALPHA_VANTAGE_API_KEY"

class FIN_AICommodities:
    def __init__(self):
        self.eia_url = "https://api.eia.gov/series/"
        self.alpha_vantage_url = "https://www.alphavantage.co/query"

    def fetch_energy_data(self):
        url = f"{self.eia_url}?api_key={EIA_API_KEY}&series_id=PET.RBRTE.D"
        data = requests.get(url).json()
        return data

    def fetch_gold_price(self):
        url = f"{self.alpha_vantage_url}?function=COMMODITY_INTRADAY&symbol=GOLD&interval=5min&apikey={ALPHA_VANTAGE_API_KEY}"
        data = requests.get(url).json()
        return data

    def generate_trade_signal(self):
        oil_data = self.fetch_energy_data()
        gold_data = self.fetch_gold_price()

        prompt = f"""
        Analyze the following commodity data (Oil, Gold) and generate a predictive AI-driven trading strategy:

        Oil Market Data: {oil_data}
        Gold Market Data: {gold_data}

        AI Optimized Trading Strategy:
        """
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "system", "content": prompt}]
        )
        return response["choices"][0]["message"]["content"]

commodity_ai = FIN_AICommodities()
print(commodity_ai.generate_trade_signal())