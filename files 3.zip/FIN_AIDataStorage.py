import json

class FIN_AIDataStorage:
    def __init__(self):
        self.data_store = {"trades": [], "consumer_trends": [], "AI_insights": []}

    def store_data(self, category, data):
        if category in self.data_store:
            self.data_store[category].append(data)
            with open(f"{category}.json", "w") as file:
                json.dump(self.data_store[category], file)

storage_ai = FIN_AIDataStorage()
storage_ai.store_data("trades", {"symbol": "AAPL", "action": "BUY", "price": 173.45})