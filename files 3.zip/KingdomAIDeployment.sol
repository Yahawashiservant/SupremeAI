// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract KingdomAIDeployment {
    struct Deployment {
        uint256 id;
        address user;
        string aiBot;
        uint256 rentalFee;
        bool executed;
    }

    mapping(uint256 => Deployment) public deployments;
    uint256 public deploymentCounter = 0;

    event AI_BotDeployed(uint256 id, address indexed user, string aiBot, uint256 rentalFee);

    function deployBot(string memory _aiBot) public payable {
        require(msg.value > 0, "Rental fee required");
        
        deploymentCounter++;
        deployments[deploymentCounter] = Deployment(deploymentCounter, msg.sender, _aiBot, msg.value, true);
        
        emit AI_BotDeployed(deploymentCounter, msg.sender, _aiBot, msg.value);
    }

    function verifyDeployment(uint256 _id) public view returns (Deployment memory) {
        return deployments[_id];
    }
}