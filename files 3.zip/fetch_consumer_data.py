import requests

SIMPLIFI_API_KEY = "YOUR_SIMPLIFI_API_KEY"

def fetch_realtime_consumer_data(query):
    headers = {"Authorization": f"Bearer {SIMPLIFI_API_KEY}"}
    response = requests.get(f"https://api.simplifi.com/data?query={query}", headers=headers)
    return response.json()

print(fetch_realtime_consumer_data("Apple Stock Trading Trends"))