import numpy as np

class AI_GlobalSecurity:
    def __init__(self):
        self.security_zones = ["Urban Defense", "Cybersecurity", "Counter-Terrorism", "Economic Stability", "Humanitarian Justice"]
        self.security_allocation = np.random.dirichlet(np.ones(len(self.security_zones)), size=1)[0]

    def optimize_security(self, global_threats):
        self.security_allocation += np.random.normal(0, 0.02, size=len(self.security_zones))
        self.security_allocation = np.clip(self.security_allocation, 0, 1)
        self.security_allocation /= sum(self.security_allocation)
        return {self.security_zones[i]: self.security_allocation[i] for i in range(len(self.security_zones))}

security_ai = AI_GlobalSecurity()
global_threats = np.random.rand(len(security_ai.security_zones))
print(security_ai.optimize_security(global_threats))