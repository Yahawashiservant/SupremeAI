import numpy as np

class SovereignWealthFund:
    def __init__(self):
        self.asset_classes = ["Equities", "Bonds", "Real Estate", "Commodities", "Tech Startups"]
        self.allocation = np.random.dirichlet(np.ones(len(self.asset_classes)), size=1)[0]

    def optimize_allocation(self, market_conditions):
        self.allocation += np.random.normal(0, 0.02, size=len(self.asset_classes))
        self.allocation = np.clip(self.allocation, 0, 1)
        self.allocation /= sum(self.allocation)
        return {self.asset_classes[i]: self.allocation[i] for i in range(len(self.asset_classes))}

fund_ai = SovereignWealthFund()
market_conditions = np.random.rand(len(fund_ai.asset_classes))
print(fund_ai.optimize_allocation(market_conditions))