import requests
import openai

ZILLOW_API_KEY = "YOUR_ZILLOW_API_KEY"

class FIN_AIRealEstate:
    def __init__(self):
        self.zillow_url = "https://api.zillow.com/v2/properties/"

    def fetch_real_estate_data(self, location):
        headers = {"Authorization": f"Bearer {ZILLOW_API_KEY}"}
        response = requests.get(f"{self.zillow_url}?location={location}", headers=headers)
        return response.json()

    def generate_real_estate_forecast(self, location):
        market_data = self.fetch_real_estate_data(location)

        prompt = f"""
        Analyze the following real estate market data for {location} and generate AI-driven property value predictions:

        Real Estate Market Data: {market_data}

        AI Forecast:
        """
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "system", "content": prompt}]
        )
        return response["choices"][0]["message"]["content"]

real_estate_ai = FIN_AIRealEstate()
print(real_estate_ai.generate_real_estate_forecast("Los Angeles, CA"))