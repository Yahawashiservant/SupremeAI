import React, { useState } from "react";

const AIChat = () => {
    const [message, setMessage] = useState("");
    const [response, setResponse] = useState("");

    const sendMessage = async () => {
        const res = await fetch("http://localhost:5000/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message }),
        });
        const data = await res.json();
        setResponse(data.response);
    };

    return (
        <div style={{ padding: "20px" }}>
            <h1>Strategic AI Assistant</h1>
            <textarea 
                value={message} 
                onChange={(e) => setMessage(e.target.value)} 
                placeholder="Ask me anything..."
                style={{ width: "100%", height: "100px" }}
            />
            <button onClick={sendMessage} style={{ marginTop: "10px" }}>Send</button>
            <p><strong>Response:</strong> {response}</p>
        </div>
    );
};

export default AIChat;