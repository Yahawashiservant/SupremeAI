import React from 'react';
import AIChat from './AIChat';

function App() {
    return (
        <div className="App">
            <AIChat />
        </div>
    );
}

export default App;