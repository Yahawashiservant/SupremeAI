import random

class FractalAI:
    def __init__(self, skillset):
        self.skillset = skillset
        self.ai_id = f"Ψ-{random.randint(1000, 9999)}-{random.choice(['A', 'B', 'C'])}"
    
    def replicate(self):
        new_ai = FractalAI(random.choice(["Marketing", "Blockchain", "Geospatial", "Economic"]))
        return new_ai

# Create a recursive AI entity
root_ai = FractalAI("Master Strategist")
new_ai_instance = root_ai.replicate()

print(f"New AI Created: {new_ai_instance.ai_id} - Specialization: {new_ai_instance.skillset}")