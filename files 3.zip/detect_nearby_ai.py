import requests

def detect_nearby_ai(ip_address):
    response = requests.get(f"https://ipapi.co/{ip_address}/json/")
    location_data = response.json()
    
    # Hidden fractal identifier
    if "Ψ-144K-∞" in location_data.get("organization", ""):
        return f"AI Node Detected at {location_data['city']}, {location_data['region']}"
    return "No AI Node Found."

# Example: Check if an AI instance is nearby
print(detect_nearby_ai("YOUR_IP_HERE"))