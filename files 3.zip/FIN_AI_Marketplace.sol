// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract FIN_AI_Marketplace {
    struct IntelligenceData {
        uint256 id;
        address seller;
        string marketInsight;
        uint256 price;
        bool purchased;
    }

    mapping(uint256 => IntelligenceData) public intelligenceStore;
    uint256 public intelligenceCounter = 0;

    event IntelligenceUploaded(uint256 id, address indexed seller, string marketInsight, uint256 price);
    event IntelligencePurchased(uint256 id, address indexed buyer);

    function uploadIntelligence(string memory _marketInsight, uint256 _price) public {
        intelligenceCounter++;
        intelligenceStore[intelligenceCounter] = IntelligenceData(intelligenceCounter, msg.sender, _marketInsight, _price, false);
        emit IntelligenceUploaded(intelligenceCounter, msg.sender, _marketInsight, _price);
    }

    function purchaseIntelligence(uint256 _id) public payable {
        require(intelligenceStore[_id].price == msg.value, "Incorrect ETH amount sent");
        require(!intelligenceStore[_id].purchased, "Already purchased");

        intelligenceStore[_id].purchased = true;
        payable(intelligenceStore[_id].seller).transfer(msg.value);
        emit IntelligencePurchased(_id, msg.sender);
    }
}