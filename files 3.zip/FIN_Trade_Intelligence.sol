// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract FIN_Trade_Intelligence {
    struct TradeSignal {
        uint256 id;
        address analyst;
        string tradingStrategy;
        uint256 price;
        bool purchased;
    }

    mapping(uint256 => TradeSignal) public tradeSignals;
    uint256 public tradeCounter = 0;

    event TradeSignalUploaded(uint256 id, address indexed analyst, string tradingStrategy, uint256 price);
    event TradeSignalPurchased(uint256 id, address indexed buyer);

    function uploadTradeSignal(string memory _tradingStrategy, uint256 _price) public {
        tradeCounter++;
        tradeSignals[tradeCounter] = TradeSignal(tradeCounter, msg.sender, _tradingStrategy, _price, false);
        emit TradeSignalUploaded(tradeCounter, msg.sender, _tradingStrategy, _price);
    }

    function purchaseTradeSignal(uint256 _id) public payable {
        require(tradeSignals[_id].price == msg.value, "Incorrect ETH amount sent");
        require(!tradeSignals[_id].purchased, "Already purchased");

        tradeSignals[_id].purchased = true;
        payable(tradeSignals[_id].analyst).transfer(msg.value);
        emit TradeSignalPurchased(_id, msg.sender);
    }
}