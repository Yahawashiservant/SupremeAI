import numpy as np

class AI_GovernmentTreasury:
    def __init__(self):
        self.sectors = ["Healthcare", "Defense", "Education", "Infrastructure", "Technology"]
        self.budget_allocation = np.random.dirichlet(np.ones(len(self.sectors)), size=1)[0]

    def optimize_allocation(self, economic_conditions):
        self.budget_allocation += np.random.normal(0, 0.02, size=len(self.sectors))
        self.budget_allocation = np.clip(self.budget_allocation, 0, 1)
        self.budget_allocation /= sum(self.budget_allocation)
        return {self.sectors[i]: self.budget_allocation[i] for i in range(len(self.sectors))}

treasury_ai = AI_GovernmentTreasury()
economic_conditions = np.random.rand(len(treasury_ai.sectors))
print(treasury_ai.optimize_allocation(economic_conditions))