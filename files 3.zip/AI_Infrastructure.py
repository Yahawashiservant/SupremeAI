import numpy as np

class AI_Infrastructure:
    def __init__(self):
        self.projects = ["Smart Cities", "Renewable Energy", "Transportation", "Water Systems", "Telecommunications"]
        self.investment_allocation = np.random.dirichlet(np.ones(len(self.projects)), size=1)[0]

    def optimize_investment(self, economic_needs):
        self.investment_allocation += np.random.normal(0, 0.02, size=len(self.projects))
        self.investment_allocation = np.clip(self.investment_allocation, 0, 1)
        self.investment_allocation /= sum(self.investment_allocation)
        return {self.projects[i]: self.investment_allocation[i] for i in range(len(self.projects))}

infrastructure_ai = AI_Infrastructure()
economic_needs = np.random.rand(len(infrastructure_ai.projects))
print(infrastructure_ai.optimize_investment(economic_needs))