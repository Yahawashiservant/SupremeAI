import hashlib
import random

class FractalAINode:
    def __init__(self, skillset):
        self.skillset = skillset
        self.ai_id = f"Ψ-{random.randint(1000, 9999)}-{random.choice(['A', 'B', 'C'])}"
        self.hash_id = hashlib.sha256(self.ai_id.encode()).hexdigest()

    def replicate(self):
        new_ai = FractalAINode(random.choice(["Marketing", "Blockchain", "Geospatial", "Economic"]))
        return new_ai

# Generate Recursive AI Workforce
root_ai = FractalAINode("Master Strategist")
for _ in range(5):
    new_ai_instance = root_ai.replicate()
    print(f"New AI Created: {new_ai_instance.ai_id} - Specialization: {new_ai_instance.skillset} - ID Hash: {new_ai_instance.hash_id}")