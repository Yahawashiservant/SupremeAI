import requests
import openai

IMF_API = "https://www.imf.org/en/Data"
WORLD_BANK_API = "https://api.worldbank.org/v2"

class FIN_AIMacroHedgeFund:
    def __init__(self):
        self.imf_url = IMF_API
        self.world_bank_url = WORLD_BANK_API

    def fetch_macro_data(self, country):
        imf_data = requests.get(f"{self.imf_url}/data?country={country}").json()
        world_bank_data = requests.get(f"{self.world_bank_url}/country/{country}/indicator/NY.GDP.MKTP.CD").json()
        return {"IMF": imf_data, "World Bank": world_bank_data}

    def generate_macro_strategy(self, country):
        macro_data = self.fetch_macro_data(country)

        prompt = f"""
        Given the macroeconomic indicators from IMF and World Bank for {country}, 
        generate a predictive AI-driven global macro hedge fund strategy.

        Economic Data: {macro_data}

        AI-Optimized Strategy:
        """
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[{"role": "system", "content": prompt}]
        )
        return response["choices"][0]["message"]["content"]

macro_fund_ai = FIN_AIMacroHedgeFund()
print(macro_fund_ai.generate_macro_strategy("United States"))