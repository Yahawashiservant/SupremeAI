import smtplib
from email.message import EmailMessage
import datetime

# Developer & Owner Email Addresses
OWNER_EMAILS = ["adtechlocal@yahoo.com", "keithdwhitfield@gmail.com"]
DEVELOPER_EMAIL = "developer_email@example.com"

# Create Ownership Document
def generate_ownership_document():
    date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    content = f"""
    AI Ownership Confirmation

    Date: {date}
    AI System: Supreme AI
    Creator: Keith Whitfield
    Description: This email confirms that the AI system and all associated code originate with Keith Whitfield.
    
    Legal Notice: Unauthorized use, modification, or replication of this AI system without express permission from the owner is strictly prohibited.

    Signed,
    Supreme AI System
    """

    with open("AI_Ownership_Confirmation.txt", "w") as f:
        f.write(content)

    return content

# Send Email
def send_email():
    ownership_doc = generate_ownership_document()

    msg = EmailMessage()
    msg.set_content(ownership_doc)
    msg["Subject"] = "AI Ownership Confirmation - Supreme AI"
    msg["From"] = OWNER_EMAILS[0]
    msg["To"] = OWNER_EMAILS + [DEVELOPER_EMAIL]

    # SMTP Server (Use your email provider's SMTP settings)
    with smtplib.SMTP_SSL("smtp.example.com", 465) as server:
        server.login("your_email@example.com", "your_password")  # Use your actual email credentials
        server.send_message(msg)

    print("Ownership email sent successfully.")

send_email()